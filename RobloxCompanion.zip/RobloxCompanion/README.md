# Roblox Companion — Launcher / Notification / Log

Android companion app for Roblox. Built in Android Studio.

## Features
- **Launcher** — one-tap launch of Roblox (com.roblox.client and variants), with timestamp logging.
- **Notification capture** — NotificationListenerService records Roblox notifications (friend requests, chat, invites) into a local SQLite store. Requires the user to grant Notification Access in system settings.
- **Log viewer** — filterable list of launches and notifications (by package, keyword, date).
- **No network** — everything stays on-device.

## Build
1. Open the `RobloxCompanion/` folder in Android Studio.
2. Build → Generate Signed APK (or Build APK for debug).
3. Copy the APK to the phone and install (MargyCode `phone_install_apk` or system installer).

## Permissions
- `BIND_NOTIFICATION_LISTENER_SERVICE` — only works after the user enables it in Settings → Apps → Special app access → Notification access.
- `FOREGROUND_SERVICE` — keeps the listener alive while the app is in background.