package com.user.robloxcompanion;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class LogActivity extends AppCompatActivity {
    private LogAdapter adapter;
    private List<LogStore.Event> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);

        RecyclerView rv = findViewById(R.id.recycler);
        EditText edtFilter = findViewById(R.id.edtFilter);
        Button btnRefresh = findViewById(R.id.btnRefresh);
        Button btnClear = findViewById(R.id.btnClear);

        data = LogStore.query(this, null, 0);
        adapter = new LogAdapter(data);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        btnRefresh.setOnClickListener(v -> {
            String kw = edtFilter.getText().toString().trim();
            data.clear();
            data.addAll(LogStore.query(this, kw.isEmpty() ? null : kw, 0));
            adapter.notifyDataSetChanged();
        });
        btnClear.setOnClickListener(v -> {
            LogStore.clear(this);
            data.clear();
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Cleared", Toast.LENGTH_SHORT).show();
        });
    }
}