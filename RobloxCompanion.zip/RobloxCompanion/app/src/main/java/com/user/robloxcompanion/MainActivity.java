package com.user.robloxcompanion;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    public static final String[] ROBLOX_PACKAGES = {
            "com.roblox.client",
            "com.roblox.client.vnggames",
            "com.tencent.roblox",
            "com.roblox.client2",
            "com.client.roblox2021"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnLaunch = findViewById(R.id.btnLaunch);
        Button btnSetWebhook = findViewById(R.id.btnSetWebhook);
        Button btnGrant = findViewById(R.id.btnGrant);
        Button btnLogs = findViewById(R.id.btnLogs);
        Button btnClear = findViewById(R.id.btnClear);
        EditText edtPkg = findViewById(R.id.edtPkg);
        EditText edtWebhook = findViewById(R.id.edtWebhook);

        edtWebhook.setText(DiscordWebhook.getUrl(this));

        btnLaunch.setOnClickListener(v -> launch(edtPkg.getText().toString().trim()));
        btnSetWebhook.setOnClickListener(v -> {
            DiscordWebhook.setUrl(this, edtWebhook.getText().toString().trim());
            Toast.makeText(this, "Webhook saved", Toast.LENGTH_SHORT).show();
        });
        btnGrant.setOnClickListener(v -> openNotificationAccess());
        btnLogs.setOnClickListener(v -> startActivity(new Intent(this, LogActivity.class)));
        btnClear.setOnClickListener(v -> {
            LogStore.clear(this);
            Toast.makeText(this, "Log cleared", Toast.LENGTH_SHORT).show();
        });

        ContextCompat.startForegroundService(this, new Intent(this, CompanionForegroundService.class));
    }

    private void launch(String pkg) {
        if (pkg.isEmpty()) pkg = "com.roblox.client";
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            Toast.makeText(this, "Not installed: " + pkg, Toast.LENGTH_SHORT).show();
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        LogStore.insert(this, "launch", pkg, "Launch", "user tapped launch");
        DiscordWebhook.postAsync(this, "🎮 Launching " + pkg + " — " + new java.util.Date());
        startActivity(i);
    }

    private void openNotificationAccess() {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Open Settings → Apps → Special access → Notification access manually",
                    Toast.LENGTH_LONG).show();
        }
    }
}