package com.user.robloxcompanion;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LogAdapter extends RecyclerView.Adapter<LogAdapter.VH> {
    private final List<LogStore.Event> data;
    private final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

    public LogAdapter(List<LogStore.Event> data) { this.data = data; }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_log, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        LogStore.Event e = data.get(pos);
        h.time.setText(fmt.format(new Date(e.ts)));
        h.type.setText(e.type + "  " + (e.pkg == null ? "" : e.pkg));
        h.body.setText((e.title == null ? "" : e.title) + " — " + (e.text == null ? "" : e.text));
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView time, type, body;
        VH(View v) {
            super(v);
            time = v.findViewById(R.id.tvTime);
            type = v.findViewById(R.id.tvType);
            body = v.findViewById(R.id.tvBody);
        }
    }
}