package com.user.robloxcompanion;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.List;

public class LogStore extends SQLiteOpenHelper {
    public static final String DB_NAME = "roblox_companion.db";
    public static final int DB_VERSION = 1;

    public static final String TABLE = "events";
    public static final String COL_ID = "_id";
    public static final String COL_TS = "ts";
    public static final String COL_TYPE = "type";       // launch | notification | error
    public static final String COL_PKG = "pkg";
    public static final String COL_TITLE = "title";
    public static final String COL_TEXT = "text";

    private static LogStore instance;

    public static synchronized LogStore get(Context c) {
        if (instance == null) instance = new LogStore(c.getApplicationContext());
        return instance;
    }

    private LogStore(Context c) { super(c, DB_NAME, null, DB_VERSION); }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_TS + " INTEGER," +
                COL_TYPE + " TEXT," +
                COL_PKG + " TEXT," +
                COL_TITLE + " TEXT," +
                COL_TEXT + " TEXT)");
        db.execSQL("CREATE INDEX idx_ts ON " + TABLE + "(" + COL_TS + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public static void insert(Context c, String type, String pkg, String title, String text) {
        ContentValues cv = new ContentValues();
        cv.put(COL_TS, System.currentTimeMillis());
        cv.put(COL_TYPE, type);
        cv.put(COL_PKG, pkg);
        cv.put(COL_TITLE, title);
        cv.put(COL_TEXT, text);
        get(c).getWritableDatabase().insert(TABLE, null, cv);
    }

    public static List<Event> query(Context c, String keyword, long sinceMs) {
        List<Event> out = new ArrayList<>();
        SQLiteDatabase db = get(c).getReadableDatabase();
        String where = COL_TS + " >= ?";
        List<String> args = new ArrayList<>();
        args.add(String.valueOf(sinceMs));
        if (keyword != null && !keyword.trim().isEmpty()) {
            where += " AND (" + COL_TITLE + " LIKE ? OR " + COL_TEXT + " LIKE ? OR " + COL_PKG + " LIKE ?)";
            String k = "%" + keyword + "%";
            args.add(k); args.add(k); args.add(k);
        }
        Cursor cur = db.query(TABLE, null, where, args.toArray(new String[0]),
                null, null, COL_TS + " DESC");
        while (cur.moveToNext()) {
            Event e = new Event();
            e.id = cur.getLong(cur.getColumnIndexOrThrow(COL_ID));
            e.ts = cur.getLong(cur.getColumnIndexOrThrow(COL_TS));
            e.type = cur.getString(cur.getColumnIndexOrThrow(COL_TYPE));
            e.pkg = cur.getString(cur.getColumnIndexOrThrow(COL_PKG));
            e.title = cur.getString(cur.getColumnIndexOrThrow(COL_TITLE));
            e.text = cur.getString(cur.getColumnIndexOrThrow(COL_TEXT));
            out.add(e);
        }
        cur.close();
        return out;
    }

    public static void clear(Context c) {
        get(c).getWritableDatabase().delete(TABLE, null, null);
    }

    public static class Event {
        public long id, ts;
        public String type, pkg, title, text;
    }
}