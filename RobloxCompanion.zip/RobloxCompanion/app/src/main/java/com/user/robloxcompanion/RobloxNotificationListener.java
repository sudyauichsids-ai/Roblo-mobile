package com.user.robloxcompanion;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.Notification;
import android.os.Bundle;

public class RobloxNotificationListener extends NotificationListenerService {
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        if (pkg == null) return;
        if (!pkg.startsWith("com.roblox") && !pkg.equals("com.tencent.roblox")) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        Bundle ex = n.extras;
        String title = ex.getString(Notification.EXTRA_TITLE);
        CharSequence text = ex.getCharSequence(Notification.EXTRA_TEXT);
        String body = text == null ? "" : text.toString();

        LogStore.insert(getApplicationContext(), "notification", pkg,
                title == null ? "" : title, body);
        DiscordWebhook.postAsync(getApplicationContext(),
                "🔔 [" + pkg + "] " + (title == null ? "" : title) + " — " + body);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) { /* no-op */ }
}