# Add your rules here to keep classes/methods/fields used by reflection etc.
# (empty by default)